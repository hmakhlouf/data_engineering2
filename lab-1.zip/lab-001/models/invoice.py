
class invoice:
    def get_invoice(invoice: str):
        return invoice
