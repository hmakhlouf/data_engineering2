from numpy import product


class get_order:
    def __init__(self, order_number, product_name, product_price):
        self.order_number = order 
        self.product_name = product
        self.product_price = price
  